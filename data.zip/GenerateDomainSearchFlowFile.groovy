import org.apache.commons.io.IOUtils
import java.nio.charset.StandardCharsets
import groovy.json.JsonSlurper
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

def formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HHmmss").withZone(ZoneId.systemDefault());
def jsonSlurper = new JsonSlurper()
flowFile = session.get()
if(!flowFile) return

try {
  def pageNumber = flowFile.getAttribute('pageNumber')
  def state = flowFile.getAttribute('state')
  def postcode = flowFile.getAttribute('postcode')
  def nextPageNumber = 0
  if(pageNumber != null){
    nextPageNumber = pageNumber.toInteger() + 1
  }

  outFlowFile = session.write(flowFile, {inputStream, outputStream ->
      def jsonObj = jsonSlurper.parseText(IOUtils.toString(inputStream, StandardCharsets.UTF_8))
      def res = '{"listingType":"Sale","locations":[{"state":"' +
                state +
                '","region":"","area":"","suburb":"","postCode":' + 
                postcode + 
                ',"includeSurroundingSuburbs":false}],"customSort":{"elements":[{"field":"AdId","direction":"Descending"}],"boostPrimarySuburbs":true},"pageNumber":' +
                nextPageNumber +
                ',"pageSize":200,"updatedSince":"2020-08-01T00:00:00.000Z","listedSince":"2020-08-01T00:00:00.000Z"}'
      
      outputStream.write(res.getBytes(StandardCharsets.UTF_8))
    } as StreamCallback)
  
  def attrMap = [
      'filename': formatter.format(Instant.now())+'_'+nextPageNumber+'.json', 
      'pageNumber': Integer.toString(nextPageNumber)
    ]
  outFlowFile = session.putAllAttributes(outFlowFile, attrMap)
  session.transfer(outFlowFile, REL_SUCCESS)

}
catch (Exception e){
  log.error('Groovy Script Error',e)
  session.transfer(flowFile, REL_FAILURE)
}